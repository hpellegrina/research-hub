RESEARCH HUB v1.1

Tasks and reports for all your research projects, on your computer and your phone.
Everything is saved as plain files in your own Dropbox.

SETUP (once)
1. Put this whole "research_hub" folder at the top level of your Dropbox,
   so it is Dropbox/research_hub (the phone app looks for it there).
2. Open the hub:
   Mac:     double-click  tracker/Research Hub.app  (drag it to your Dock for one click)
            First time: if the Mac says it can't check the app, open System Settings >
            Privacy & Security, scroll down and click "Open Anyway".
   Windows: double-click  tracker/Open Research Hub (Windows).bat
   Needs Python 3 (the Mac offers to install it the first time; on Windows get it
   from python.org).
3. Your browser opens the hub. It stops by itself a few minutes after you close the page.

ADDING PROJECTS
Click "+ Add project" in the hub, type a name, and choose the folder in your Dropbox where
that project's PDFs are saved (for example a folder you share with coauthors). The PDFs
stay where they are; the hub just shows them. "Rename" (next to a project's title)
changes its name; "Renumber 1, 2, 3..." (in the sidebar, when numbers have gaps) fixes the
numbering. "Remove project..." (at the bottom of a project's page) takes it out of the hub
without deleting anything.

ON YOUR PHONE
Open the Research Hub website (the link you were given), tap "Open the phone app",
and follow the steps there. New projects show up on the phone automatically.

WHAT'S IN THE FOLDER
tracker/                         the hub program
projects/<name>/TASKS.md         the project's tasks (To do, Completed, Archived)
projects/<name>/REPORTS.txt      first line: where the PDFs are, inside Dropbox
projects/<name>/reports/         ...or put the PDFs here instead
projects/<name>/READ_REPORTS.txt      reports you've marked as read
projects/<name>/ARCHIVED_REPORTS.txt  reports you've archived
removed_projects/                projects you removed from the hub (nothing is deleted)

All of these are plain text, so you can also read or edit them in the Dropbox app.
Your tasks and marks stay private in your research_hub folder; shared folders with
PDFs are only read, never changed.
