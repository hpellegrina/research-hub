# 1. Example project

## To do
- [ ] Click the circle to mark a task done
- [ ] Add your own projects with "+ Add project", then remove this one ("Remove project..." at the bottom)

## Completed
- [x] Install the Research Hub (done 2026-09-30)
