@echo off
rem Start the Research Hub. It opens in your browser and stops by itself
rem a few minutes after you close the hub page.
cd /d "%~dp0"
where py >nul 2>nul && (start "Research Hub" /min py tracker.py) || (start "Research Hub" /min python tracker.py)
