#!/usr/bin/env python3
"""
Research Hub tracker.

Run this file and a page opens in your browser with one tab per project.
Projects are the folders inside  research_hub/projects/.
Each project's tasks are stored in a plain text file:  projects/<name>/TASKS.md
Reports are any files inside  projects/<name>/reports/

Uses only the Python standard library. Nothing to install.
"""

import json
import re
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse
import mimetypes

VERSION = "1.2"
PORT = 8765
IDLE_LIMIT = 180  # seconds with no open hub page before the tracker stops itself
last_seen = time.time()
HUB = Path(__file__).resolve().parent.parent
PROJECTS = HUB / "projects"
REMOVED = HUB / "removed_projects"  # "Remove project" moves folders here; nothing is deleted
DROPBOX = HUB.parent

READ_FILE = "READ_REPORTS.txt"  # per project: names of reports marked as read (shared with the phone app)
ARCHIVE_FILE = "ARCHIVED_REPORTS.txt"  # per project: names of archived reports
MARK_HEADERS = {
    READ_FILE: "# Reports marked as read in the Research Hub app (one file name per line).",
    ARCHIVE_FILE: "# Reports archived in the Research Hub app (one file name per line).",
}
HEADING_RE = re.compile(r"^\s*#+\s*(.*?)\s*$")
TASK_RE = re.compile(r"^\s*[-*]\s*\[( |x|X)\]\s*(.*?)\s*$")
DONE_RE = re.compile(r"\s+\(done (\d{4}-\d{2}-\d{2})\)$")


# ---------- tasks file ----------

def natural_key(name):
    # Compare numbers as numbers, so "10. X" sorts after "9. Y" instead of after "1. Z".
    return [(0, int(s), "") if s.isdigit() else (1, 0, s) for s in re.split(r"(\d+)", name.lower())]


def project_dirs():
    PROJECTS.mkdir(parents=True, exist_ok=True)
    return sorted(
        [p for p in PROJECTS.iterdir() if p.is_dir() and not p.name.startswith(".")],
        key=lambda p: natural_key(p.name),
    )


def get_project(name):
    for p in project_dirs():
        if p.name == name:
            return p
    return None


def read_tasks(pdir):
    f = pdir / "TASKS.md"
    tasks = []
    if not f.exists():
        return tasks
    archived = False  # tasks under an "## Archived" heading are archived
    for line in f.read_text(encoding="utf-8").splitlines():
        h = HEADING_RE.match(line)
        if h:
            archived = h.group(1).lower() == "archived"
            continue
        m = TASK_RE.match(line)
        if not m:
            continue
        done = m.group(1).lower() == "x"
        text = m.group(2)
        when = None
        d = DONE_RE.search(text)
        if d:
            when = d.group(1)
            text = text[: d.start()]
        if text:
            tasks.append({"text": text, "done": done, "date": when, "archived": archived})
    return tasks


def task_line(t):
    if not t["done"]:
        return f"- [ ] {t['text']}"
    suffix = f" (done {t['date']})" if t.get("date") else ""
    return f"- [x] {t['text']}{suffix}"


def write_tasks(pdir, tasks):
    active = [t for t in tasks if not t.get("archived")]
    archived = [t for t in tasks if t.get("archived")]
    lines = [f"# {pdir.name}", "", "## To do"]
    lines += [task_line(t) for t in active if not t["done"]]
    lines += ["", "## Completed"]
    lines += [task_line(t) for t in active if t["done"]]
    if archived:
        lines += ["", "## Archived"] + [task_line(t) for t in archived]
    (pdir / "TASKS.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def find_task(tasks, index, text):
    if 0 <= index < len(tasks) and tasks[index]["text"] == text:
        return index
    for i, t in enumerate(tasks):  # file changed elsewhere; match by text
        if t["text"] == text:
            return i
    return -1


def reports_dir(pdir):
    # A project's PDFs are in its own "reports" folder, or in the Dropbox folder named on
    # the first line of its REPORTS.txt (e.g. "gold_rush/reports"), relative to Dropbox.
    pointer = pdir / "REPORTS.txt"
    if pointer.is_file():
        lines = pointer.read_text(encoding="utf-8").strip().splitlines()
        if lines and lines[0].strip():
            return DROPBOX / lines[0].strip()
    return pdir / "reports"


def list_reports(pdir):
    rdir = reports_dir(pdir)
    if not rdir.is_dir():
        return []
    files = [f for f in rdir.iterdir() if f.is_file() and not f.name.startswith(".")]
    # Newest first, to the second (like Dropbox); same-second files by name, reversed. Same rule as the phone app.
    files.sort(key=lambda f: natural_key(f.name), reverse=True)
    files.sort(key=lambda f: int(f.stat().st_mtime), reverse=True)
    read, archived = read_marks(pdir, READ_FILE), read_marks(pdir, ARCHIVE_FILE)
    return [
        {
            "name": f.name,
            "modified": date.fromtimestamp(f.stat().st_mtime).isoformat(),
            "read": f.name in read,
            "archived": f.name in archived,
        }
        for f in files
    ]


def read_marks(pdir, fname):
    f = pdir / fname
    if not f.exists():
        return set()
    lines = (l.strip() for l in f.read_text(encoding="utf-8").splitlines())
    return {l for l in lines if l and not l.startswith("#")}


def write_marks(pdir, fname, marks):
    # Only keep reports that still exist, so the file doesn't grow forever (same as the phone app).
    names = [r["name"] for r in list_reports(pdir) if r["name"] in marks]
    (pdir / fname).write_text("\n".join([MARK_HEADERS[fname], *names]) + "\n", encoding="utf-8")


def project_summary(pdir):
    tasks = read_tasks(pdir)
    reports = list_reports(pdir)
    return {
        "name": pdir.name,
        "open": sum(not t["done"] and not t["archived"] for t in tasks),
        "unread": sum(not r["read"] and not r["archived"] for r in reports),
    }


def project_detail(pdir):
    return {"name": pdir.name, "tasks": read_tasks(pdir), "reports": list_reports(pdir)}


# ---------- adding and removing projects ----------

def clean_name(name):
    name = " ".join(str(name).split())
    if not name or name.startswith(".") or any(c in name for c in '/\\:') or len(name) > 100:
        raise ValueError("Please use a project name without / \\ or : (and not starting with a dot).")
    return name


def reports_path(rel):
    # A reports folder given relative to Dropbox (as REPORTS.txt stores it); it must exist.
    rel = str(rel or "").strip().strip("/")
    if not rel:
        return ""
    if ".." in Path(rel).parts or not (DROPBOX / rel).is_dir():
        raise ValueError(f"Couldn't find the folder {rel} in your Dropbox.")
    return rel


def add_project(name, reports):
    name, rel = clean_name(name), reports_path(reports)
    if any(p.name.lower() == name.lower() for p in project_dirs()):
        raise ValueError(f"There is already a project called {name}.")
    pdir = PROJECTS / name
    pdir.mkdir(parents=True)
    if rel:
        (pdir / "REPORTS.txt").write_text(
            f"{rel}\n\nThe PDFs for this project are in the Dropbox folder named on the first line.\n"
            "The Research Hub reads the first line to show these PDFs, so keep it as is.\n",
            encoding="utf-8",
        )
    else:
        (pdir / "reports").mkdir()
    return pdir


def remove_project(pdir):
    # Move the project's folder (tasks, read marks) out of the hub. The PDFs are never touched.
    REMOVED.mkdir(exist_ok=True)
    target, n = REMOVED / pdir.name, 2
    while target.exists():
        target, n = REMOVED / f"{pdir.name} ({n})", n + 1
    shutil.move(str(pdir), str(target))


NUMBER_RE = re.compile(r"^(\d+)\.\s+(.*)$")


def rename_project(pdir, new_name):
    # Rename the project's folder (its tasks, read marks and archive go with it). PDFs are untouched.
    new_name = clean_name(new_name)
    if new_name == pdir.name:
        return pdir
    if any(p.name.lower() == new_name.lower() and p != pdir for p in project_dirs()):
        raise ValueError(f"There is already a project called {new_name}.")
    target = pdir.with_name(new_name)
    pdir.rename(target)
    tasks = target / "TASKS.md"
    if tasks.exists():  # keep the title line in step with the new name
        lines = tasks.read_text(encoding="utf-8").split("\n")
        if lines and lines[0] == f"# {pdir.name}":
            lines[0] = f"# {new_name}"
            tasks.write_text("\n".join(lines), encoding="utf-8")
    return target


def renumbering():
    # Numbered projects ("7. Name"), in their current order, numbered 1, 2, 3... again.
    numbered = [(p, NUMBER_RE.match(p.name)) for p in project_dirs()]
    numbered = [(p, m.group(2)) for p, m in numbered if m]
    return [(p, f"{i}. {rest}") for i, (p, rest) in enumerate(numbered, 1) if p.name != f"{i}. {rest}"]


def renumber_projects():
    changes = renumbering()
    # Two steps, via temporary hidden names, so no two projects ever share a name midway.
    temp = []
    for i, (p, new) in enumerate(changes):
        t = p.with_name(f".renaming-{i}")
        p.rename(t)
        temp.append((t, p.name, new))
    for t, old, new in temp:
        target = t.with_name(new)
        t.rename(target)
        tasks = target / "TASKS.md"
        if tasks.exists():
            lines = tasks.read_text(encoding="utf-8").split("\n")
            if lines and lines[0] == f"# {old}":
                lines[0] = f"# {new}"
                tasks.write_text("\n".join(lines), encoding="utf-8")
    return [(old, new) for _, old, new in temp]


def choose_folder():
    # Show the Mac's own folder picker, starting in Dropbox. Returns the folder relative to Dropbox.
    if sys.platform != "darwin":
        return {"manual": True}
    script = [
        "on run argv",
        "tell me to activate",
        "return POSIX path of (choose folder with prompt (item 1 of argv) default location (POSIX file (item 2 of argv)))",
        "end run",
    ]
    args = ["osascript"] + [a for line in script for a in ("-e", line)]
    res = subprocess.run(args + ["Choose the folder with this project's reports", str(DROPBOX)],
                         capture_output=True, text=True)
    if res.returncode != 0:
        return {"cancelled": True}
    chosen = Path(res.stdout.strip()).resolve()
    try:
        rel = chosen.relative_to(DROPBOX.resolve())
    except ValueError:
        return {"error": "Please choose a folder inside your Dropbox, so your phone can see it too."}
    return {"path": rel.as_posix()}


# ---------- web server ----------

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def send_json(self, obj, status=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def parts(self):
        return [unquote(p) for p in urlparse(self.path).path.strip("/").split("/") if p]

    def do_GET(self):
        global last_seen
        last_seen = time.time()
        parts = self.parts()
        if not parts:
            body = PAGE.replace("__VERSION__", VERSION).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif parts == ["api", "ping"]:
            self.send_json({"ok": True})
        elif parts == ["api", "projects"]:
            self.send_json([project_summary(p) for p in project_dirs()])
        elif len(parts) == 3 and parts[:2] == ["api", "project"]:
            pdir = get_project(parts[2])
            if pdir:
                self.send_json(project_detail(pdir))
            else:
                self.send_json({"error": "Project not found"}, 404)
        elif len(parts) == 3 and parts[0] == "reports":
            pdir = get_project(parts[1])
            fname = Path(parts[2]).name
            f = reports_dir(pdir) / fname if pdir else None
            if f and f.is_file():
                data = f.read_bytes()
                ctype = mimetypes.guess_type(fname)[0] or "application/octet-stream"
                self.send_response(200)
                self.send_header("Content-Type", ctype)
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            else:
                self.send_json({"error": "File not found"}, 404)
        else:
            self.send_json({"error": "Not found"}, 404)

    def do_POST(self):
        parts = self.parts()
        length = int(self.headers.get("Content-Length", 0))
        try:
            data = json.loads(self.rfile.read(length) or b"{}")
        except json.JSONDecodeError:
            return self.send_json({"error": "Bad request"}, 400)

        if parts == ["api", "choose-folder"]:
            return self.send_json(choose_folder())
        if parts == ["api", "projects", "add"]:
            try:
                pdir = add_project(data.get("name", ""), data.get("reports", ""))
            except ValueError as e:
                return self.send_json({"error": str(e)}, 400)
            return self.send_json({"name": pdir.name})
        if parts == ["api", "projects", "rename"]:
            pdir = get_project(data.get("name", ""))
            if not pdir:
                return self.send_json({"error": "Project not found"}, 404)
            try:
                pdir = rename_project(pdir, data.get("new_name", ""))
            except ValueError as e:
                return self.send_json({"error": str(e)}, 400)
            return self.send_json({"name": pdir.name})
        if parts == ["api", "projects", "renumber"]:
            if data.get("preview"):
                return self.send_json({"changes": [[p.name, new] for p, new in renumbering()]})
            return self.send_json({"changes": renumber_projects()})
        if parts == ["api", "projects", "remove"]:
            pdir = get_project(data.get("name", ""))
            if not pdir:
                return self.send_json({"error": "Project not found"}, 404)
            remove_project(pdir)
            return self.send_json({"ok": True})

        if len(parts) != 4 or parts[:2] != ["api", "project"]:
            return self.send_json({"error": "Not found"}, 404)
        pdir = get_project(parts[2])
        if not pdir:
            return self.send_json({"error": "Project not found"}, 404)

        action = parts[3]
        if action in ("read", "readall", "archive-report", "unarchive-report"):
            fname = READ_FILE if action.startswith("read") else ARCHIVE_FILE
            marks = read_marks(pdir, fname)
            name = str(data.get("name", ""))
            if action == "readall":
                marks |= {r["name"] for r in list_reports(pdir) if not r["archived"]}
            elif action == "archive-report" or (action == "read" and data.get("read")):
                marks.add(name)
            else:
                marks.discard(name)
            write_marks(pdir, fname, marks)
            return self.send_json(project_detail(pdir))

        tasks = read_tasks(pdir)
        if action == "add":
            text = " ".join(str(data.get("text", "")).split())
            if text:
                tasks.append({"text": text, "done": False, "date": None})
        elif action in ("toggle", "delete", "archive", "unarchive"):
            i = find_task(tasks, int(data.get("index", -1)), data.get("text", ""))
            if i < 0:
                return self.send_json({"error": "That task changed in another window. Reloaded."}, 409)
            if action == "toggle":
                t = tasks[i]
                t["done"] = not t["done"]
                t["date"] = date.today().isoformat() if t["done"] else None
            elif action == "delete":
                tasks.pop(i)
            else:
                tasks[i]["archived"] = action == "archive"
        else:
            return self.send_json({"error": "Unknown action"}, 404)
        write_tasks(pdir, tasks)
        self.send_json(project_detail(pdir))


PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Research hub</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,500;6..72,600&family=Public+Sans:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root {
  --paper: #EEF1F4;
  --sheet: #FFFFFF;
  --ink: #18212C;
  --muted: #5F6B78;
  --rule: #D5DBE2;
  --accent: #23508C;
  --accent-soft: #DCE6F3;
  --done: #4F7A5A;
  --serif: "Newsreader", "Iowan Old Style", Georgia, serif;
  --sans: "Public Sans", -apple-system, "Segoe UI", Roboto, sans-serif;
}
@media (prefers-color-scheme: dark) {
  :root {
    --paper: #151B23; --sheet: #1D2530; --ink: #E6EAF0; --muted: #98A3B0;
    --rule: #2F3A47; --accent: #8FB3E8; --accent-soft: #263A55; --done: #8CBF98;
  }
}
* { box-sizing: border-box; }
html, body { height: 100%; margin: 0; }
body { background: var(--paper); color: var(--ink); font: 16px/1.5 var(--sans); }
button, input { font: inherit; color: inherit; }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

.app { display: grid; grid-template-columns: 250px 1fr; min-height: 100%; }

nav { padding: 28px 16px; border-right: 1px solid var(--rule); }
nav h1 { font: 600 1.35rem/1.2 var(--serif); margin: 0 10px 22px; }
.tabs { list-style: none; margin: 0; padding: 0; display: flex; flex-direction: column; gap: 2px; }
.tab {
  width: 100%; display: block;
  padding: 9px 10px; border: 0; border-radius: 6px; background: none; cursor: pointer; text-align: left;
}
.tab:hover { background: var(--accent-soft); }
.tab[aria-selected="true"] { background: var(--sheet); box-shadow: inset 3px 0 0 var(--accent); font-weight: 600; }
.tabsub { display: block; color: var(--muted); font-size: .8rem; font-weight: 400; font-variant-numeric: tabular-nums; }
.tabsub b { color: var(--accent); font-weight: 600; }

main { padding: 40px clamp(20px, 5vw, 64px); max-width: 820px; }
.title { font: 600 clamp(1.8rem, 4vw, 2.5rem)/1.15 var(--serif); margin: 0 0 6px; overflow-wrap: anywhere; }
.subtitle { color: var(--muted); margin: 0 0 28px; }

.add { display: flex; gap: 8px; margin-bottom: 26px; }
.add input {
  flex: 1; min-width: 0; padding: 11px 14px; border: 1px solid var(--rule); border-radius: 8px; background: var(--sheet);
}
.add button, .primary {
  padding: 11px 18px; border: 0; border-radius: 8px; background: var(--accent); color: var(--sheet); font-weight: 600; cursor: pointer;
}

section { margin-bottom: 34px; }
h3 { font: 600 1.1rem/1.3 var(--serif); margin: 0 0 10px; }
.list { list-style: none; margin: 0; padding: 0; background: var(--sheet); border: 1px solid var(--rule); border-radius: 10px; }
.list:empty { display: none; }
.list li { display: flex; align-items: flex-start; gap: 12px; padding: 12px 14px; border-top: 1px solid var(--rule); }
.list li:first-child { border-top: 0; }
.check {
  flex: none; width: 22px; height: 22px; margin-top: 1px; border: 2px solid var(--muted); border-radius: 50%;
  background: none; cursor: pointer; display: grid; place-items: center; padding: 0;
}
.check:hover { border-color: var(--done); }
.done .check { background: var(--done); border-color: var(--done); }
.done .check::after { content: ""; width: 6px; height: 11px; border: solid var(--sheet); border-width: 0 2px 2px 0; transform: translateY(-1px) rotate(45deg); }
.text { flex: 1; overflow-wrap: anywhere; }
.done .text { color: var(--muted); text-decoration: line-through; text-decoration-color: var(--rule); }
.date { color: var(--muted); font-size: .85rem; white-space: nowrap; }
.remove { flex: none; border: 0; background: none; color: var(--muted); cursor: pointer; opacity: 0; padding: 0 4px; font-size: 1.1rem; line-height: 1.3; }
.archive { flex: none; border: 0; background: none; color: var(--muted); cursor: pointer; opacity: 0; padding: 2px 4px; display: grid; place-items: center; }
.archive:hover { color: var(--accent); }
.archive svg { width: 17px; height: 17px; }
li:hover .remove, .remove:focus-visible, li:hover .archive, .archive:focus-visible { opacity: 1; }
@media (hover: none) { .remove, .archive { opacity: .6; } }
.restore { flex: none; border: 1px solid var(--rule); background: none; color: var(--accent); border-radius: 99px; padding: 2px 10px; cursor: pointer; font-size: .8rem; font-weight: 600; }
.restore:hover { background: var(--accent-soft); }
.archive-box h4 { font: 600 .8rem/1.3 var(--sans); text-transform: uppercase; letter-spacing: .05em; color: var(--muted); margin: 14px 0 6px; }
.archive-box .text, .archive-box a { color: var(--muted); }

.empty { color: var(--muted); padding: 4px 0 0; margin: 0; }
details summary { cursor: pointer; list-style: none; }
details summary::-webkit-details-marker { display: none; }
details summary h3 { display: inline; }
details summary::before { content: "▸"; color: var(--muted); display: inline-block; width: 1.1em; transition: transform .15s; }
details[open] summary::before { transform: rotate(90deg); }
details .list { margin-top: 10px; }

.reports a { color: var(--accent); text-decoration: none; flex: 1; overflow-wrap: anywhere; }
.reports a:hover { text-decoration: underline; }
.reports li { align-items: center; }
.reports .unread a { font-weight: 600; }
.reports .read a { color: var(--muted); }
.readbtn { flex: none; padding: 3px 11px; border-radius: 99px; border: 1px solid var(--accent); background: none; color: var(--accent); cursor: pointer; font-size: .8rem; font-weight: 600; white-space: nowrap; }
.readbtn:hover { background: var(--accent-soft); }
.readbtn[aria-pressed="true"] { border-color: transparent; color: var(--done); font-weight: 500; }
.section-head { display: flex; align-items: baseline; justify-content: space-between; gap: 10px; }
.section-head h3 { margin-bottom: 10px; }
.link-btn { border: 0; background: none; color: var(--accent); cursor: pointer; font-size: .9rem; padding: 0; }
.link-btn:hover { text-decoration: underline; }

.flash { animation: flash .6s ease-out; }
@keyframes flash { from { background: var(--accent-soft); } to { background: transparent; } }
.toast { position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%); background: var(--ink); color: var(--paper); padding: 10px 16px; border-radius: 8px; font-size: .9rem; }
.toast[hidden] { display: none; }

@media (max-width: 720px) {
  .app { grid-template-columns: 1fr; }
  nav { padding: 18px 12px 10px; border-right: 0; border-bottom: 1px solid var(--rule); }
  nav h1 { margin-bottom: 12px; }
  .tabs { flex-direction: row; overflow-x: auto; }
  .tab { width: auto; white-space: nowrap; }
  .tab[aria-selected="true"] { box-shadow: inset 0 -3px 0 var(--accent); }
  main { padding-top: 26px; }
}
.new-project { width: 100%; margin-top: 12px; padding: 9px 10px; border: 1px dashed var(--rule); border-radius: 6px; background: none; color: var(--accent); cursor: pointer; text-align: left; font-weight: 600; }
.new-project:hover { background: var(--accent-soft); border-style: solid; }
.renumber { margin: 8px 10px 0; font-size: .85rem; }
.renumber[hidden] { display: none; }
.title-row { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; }
.title-row .title { margin-bottom: 6px; }
.rename-btn { font-size: .9rem; }
.version { margin: 18px 10px 0; color: var(--muted); font-size: .78rem; }
.danger-zone { margin-top: 40px; padding-top: 16px; border-top: 1px solid var(--rule); }
.link-btn.muted { color: var(--muted); }

dialog { border: 1px solid var(--rule); border-radius: 12px; padding: 24px; width: min(460px, calc(100% - 32px)); background: var(--sheet); color: var(--ink); }
dialog::backdrop { background: rgba(10, 16, 24, .45); }
dialog h2 { font: 600 1.35rem/1.2 var(--serif); margin: 0 0 16px; }
dialog label { display: block; font-weight: 600; font-size: .9rem; margin: 14px 0 6px; }
dialog .hint { color: var(--muted); font-size: .85rem; margin: 6px 0 0; }
dialog input[type=text] { width: 100%; padding: 10px 12px; border: 1px solid var(--rule); border-radius: 8px; background: var(--paper); }
.folder-row { display: flex; gap: 8px; align-items: center; }
.folder-path { flex: 1; min-width: 0; padding: 10px 12px; border: 1px solid var(--rule); border-radius: 8px; background: var(--paper); color: var(--muted); overflow-wrap: anywhere; font-size: .9rem; }
.folder-path.set { color: var(--ink); }
.secondary { padding: 10px 14px; border: 1px solid var(--rule); border-radius: 8px; background: none; cursor: pointer; font-weight: 600; white-space: nowrap; }
.secondary:hover { background: var(--accent-soft); }
.dialog-actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 22px; }
.form-error { color: #B3261E; font-size: .9rem; margin: 12px 0 0; }
@media (prefers-color-scheme: dark) { .form-error { color: #F2B8B5; } }
@media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
</style>
</head>
<body>
<div class="app">
  <nav>
    <h1>Research hub</h1>
    <ul class="tabs" id="tabs" role="tablist"></ul>
    <button class="new-project" id="new-project">+ Add project</button>
    <button class="link-btn renumber" id="renumber" hidden>Renumber 1, 2, 3…</button>
    <p class="version">Research Hub v__VERSION__</p>
  </nav>
  <main id="main"></main>
</div>
<dialog id="add-dialog" aria-labelledby="add-title">
  <form id="add-form" method="dialog">
    <h2 id="add-title">Add project</h2>
    <label for="p-name">Project name</label>
    <input type="text" id="p-name" autocomplete="off" required>
    <label>Reports folder</label>
    <div class="folder-row">
      <span class="folder-path" id="p-folder">None yet</span>
      <button type="button" class="secondary" id="p-choose">Choose folder…</button>
    </div>
    <p class="hint">The folder in your Dropbox where this project's PDFs are saved. Leave it empty to put PDFs in the project's own <b>reports</b> folder.</p>
    <p class="form-error" id="p-error" hidden></p>
    <div class="dialog-actions">
      <button type="button" class="secondary" id="p-cancel">Cancel</button>
      <button type="submit" class="primary">Add project</button>
    </div>
  </form>
</dialog>
<dialog id="rename-dialog" aria-labelledby="rename-title">
  <form id="rename-form" method="dialog">
    <h2 id="rename-title">Rename project</h2>
    <label for="r-name">New name</label>
    <input type="text" id="r-name" autocomplete="off" required>
    <p class="hint">Its tasks, read marks and archive stay with it. The PDFs aren't touched.</p>
    <p class="form-error" id="r-error" hidden></p>
    <div class="dialog-actions">
      <button type="button" class="secondary" id="r-cancel">Cancel</button>
      <button type="submit" class="primary">Rename</button>
    </div>
  </form>
</dialog>
<div class="toast" id="toast" hidden></div>

<script>
let projects = [];
let current = localStorage.getItem("hub-current");
let lastChanged = null;

const $ = (s) => document.querySelector(s);
const ARCHIVE_ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9"/><path d="M10 13h4"/></svg>`;
const esc = (s) => s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));

function toast(msg) {
  const t = $("#toast"); t.textContent = msg; t.hidden = false;
  clearTimeout(t._h); t._h = setTimeout(() => t.hidden = true, 2600);
}

async function api(path, body) {
  const res = await fetch(path, body ? { method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body) } : {});
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

async function loadProjects() {
  projects = await api("/api/projects");
  if (!projects.find(p => p.name === current)) current = projects[0]?.name || null;
  renderTabs();
  if (current) await openProject(current); else renderEmptyHub();
}

function renderTabs() {
  $("#tabs").innerHTML = projects.map(p => `
    <li><button class="tab" role="tab" aria-selected="${p.name === current}" data-name="${esc(p.name)}">
      ${esc(p.name)}<span class="tabsub">${tabSummary(p)}</span>
    </button></li>`).join("");
  // Offer to renumber when numbered projects have gaps (e.g. 1-7 and 10).
  const nums = projects.map(p => /^(\d+)\.\s/.exec(p.name)).filter(Boolean).map(m => +m[1]);
  $("#renumber").hidden = !nums.some((n, i) => n !== i + 1);
}

function tabSummary(p) {
  const tasks = p.open ? `${p.open} to do` : "no tasks";
  return p.unread ? `${tasks} · <b>${p.unread} unread</b>` : tasks;
}

function renderEmptyHub() {
  $("#main").innerHTML = `<h2 class="title">No projects yet</h2>
    <p class="subtitle">Click <b>+ Add project</b> to add your first one.</p>
    <button class="primary" onclick="openAddDialog()">Add project</button>`;
}

// ---------- add / remove projects ----------
let chosenFolder = "";

function suggestName() {
  // If projects are numbered ("7. Name"), start the new one with the next number.
  const nums = projects.map(p => /^(\d+)\.\s/.exec(p.name)).filter(Boolean).map(m => +m[1]);
  return nums.length && nums.length === projects.length ? `${Math.max(...nums) + 1}. ` : "";
}

function setFolder(rel) {
  chosenFolder = rel;
  const f = $("#p-folder");
  f.textContent = rel ? "Dropbox/" + rel : "None yet";
  f.classList.toggle("set", !!rel);
}

function formError(msg) { const e = $("#p-error"); e.textContent = msg || ""; e.hidden = !msg; }

function openAddDialog() {
  $("#p-name").value = suggestName();
  setFolder(""); formError("");
  $("#add-dialog").showModal();
  const input = $("#p-name"); input.focus(); input.setSelectionRange(input.value.length, input.value.length);
}

$("#new-project").onclick = openAddDialog;
$("#p-cancel").onclick = () => $("#add-dialog").close();

$("#p-choose").onclick = async () => {
  formError("");
  const btn = $("#p-choose"); btn.disabled = true; btn.textContent = "Choosing…";
  try {
    const r = await api("/api/choose-folder", {});
    if (r.manual) {
      const rel = prompt("Type the reports folder's path inside your Dropbox (for example: my_project/reports):", chosenFolder);
      if (rel !== null) setFolder(rel.trim().replace(/^\/+|\/+$/g, ""));
    } else if (r.error) formError(r.error);
    else if (r.path) {
      setFolder(r.path);
      // Suggest a name from the folder if none typed yet (skip generic names like "reports").
      const parts = r.path.split("/"), generic = /^(reports?|pdfs?|output|docs?)$/i;
      const guess = parts.length > 1 && generic.test(parts.at(-1)) ? parts.at(-2) : parts.at(-1);
      const input = $("#p-name");
      if (input.value.trim() === suggestName().trim()) input.value = suggestName() + guess.replace(/[_-]+/g, " ");
    }
  } catch (e) { formError(e.message); }
  finally { btn.disabled = false; btn.textContent = "Choose folder…"; }
};

$("#add-form").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const r = await api("/api/projects/add", { name: $("#p-name").value, reports: chosenFolder });
    $("#add-dialog").close();
    current = r.name;
    await loadProjects();
    toast(`Added ${r.name}`);
  } catch (err) { formError(err.message); }
};

function openRenameDialog() {
  const input = $("#r-name");
  input.value = current;
  const e = $("#r-error"); e.hidden = true;
  $("#rename-dialog").showModal();
  input.focus(); input.select();
}
$("#r-cancel").onclick = () => $("#rename-dialog").close();
$("#rename-form").onsubmit = async (ev) => {
  ev.preventDefault();
  try {
    const r = await api("/api/projects/rename", { name: current, new_name: $("#r-name").value });
    $("#rename-dialog").close();
    current = r.name;
    await loadProjects();
    toast(`Renamed to ${r.name}`);
  } catch (err) { const e = $("#r-error"); e.textContent = err.message; e.hidden = false; }
};

$("#renumber").onclick = async () => {
  try {
    const { changes } = await api("/api/projects/renumber", { preview: true });
    if (!changes.length) return toast("The numbers are already 1, 2, 3…");
    const list = changes.map(([a, b]) => `${a}  →  ${b}`).join("\n");
    if (!confirm(`Renumber these projects?\n\n${list}\n\nTheir tasks, read marks and archive stay with them.`)) return;
    const pos = changes.findIndex(([a]) => a === current);
    await api("/api/projects/renumber", {});
    if (pos >= 0) current = changes[pos][1];
    await loadProjects();
    toast("Projects renumbered");
  } catch (e) { toast(e.message); }
};

async function removeProject(name) {
  if (!confirm(`Remove "${name}" from the hub?\n\nNothing is deleted: its tasks and read marks move to research_hub/removed_projects, and the PDFs stay where they are.`)) return;
  try {
    await api("/api/projects/remove", { name });
    current = null;
    await loadProjects();
    toast(`Removed ${name}. You can find it in research_hub/removed_projects.`);
  } catch (e) { toast(e.message); }
}

async function openProject(name) {
  current = name;
  try { localStorage.setItem("hub-current", name); } catch (e) {}
  renderTabs();
  try { render(await api("/api/project/" + encodeURIComponent(name))); }
  catch (e) { toast(e.message); }
}

function render(p) {
  const all = p.tasks.map((t, i) => ({...t, i}));
  const tasks = all.filter(t => !t.archived), archivedTasks = all.filter(t => t.archived);
  const open = tasks.filter(t => !t.done);
  const done = tasks.filter(t => t.done).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  const reports = p.reports.filter(r => !r.archived), archivedReports = p.reports.filter(r => r.archived);
  const unread = reports.filter(r => !r.read).length;
  const archivedCount = archivedTasks.length + archivedReports.length;
  const reportLink = r => `<a href="/reports/${encodeURIComponent(p.name)}/${encodeURIComponent(r.name)}" target="_blank">${esc(r.name)}</a>`;
  const row = t => `
    <li class="${t.done ? "done" : ""} ${t.text === lastChanged ? "flash" : ""}">
      <button class="check" data-act="toggle" data-i="${t.i}" aria-label="${t.done ? "Mark as not done" : "Mark as done"}: ${esc(t.text)}"></button>
      <span class="text">${esc(t.text)}</span>
      ${t.date ? `<span class="date">${t.date}</span>` : ""}
      <button class="archive" data-act="archive" data-i="${t.i}" title="Archive" aria-label="Archive task: ${esc(t.text)}">${ARCHIVE_ICON}</button>
      <button class="remove" data-act="delete" data-i="${t.i}" aria-label="Delete task: ${esc(t.text)}">×</button>
    </li>`;

  $("#main").innerHTML = `
    <div class="title-row">
      <h2 class="title">${esc(p.name)}</h2>
      <button class="link-btn rename-btn" data-rename-project>Rename</button>
    </div>
    <p class="subtitle">${open.length} to do, ${done.length} completed · ${reports.length} ${reports.length === 1 ? "report" : "reports"}, ${unread} unread${archivedCount ? ` · ${archivedCount} archived` : ""}</p>
    <form class="add" id="add">
      <input id="newtask" placeholder="Add a task to ${esc(p.name)}" autocomplete="off" aria-label="New task">
      <button type="submit">Add</button>
    </form>
    <section>
      <h3>To do</h3>
      ${open.length ? "" : `<p class="empty">Nothing to do here. Add a task above.</p>`}
      <ul class="list">${open.map(row).join("")}</ul>
    </section>
    <section>
      <details ${done.length && done.length <= 8 ? "open" : ""}>
        <summary><h3>Completed (${done.length})</h3></summary>
        <ul class="list">${done.map(row).join("")}</ul>
      </details>
    </section>
    <section class="reports">
      <div class="section-head">
        <h3>Reports</h3>
        ${unread ? `<button class="link-btn" data-allread>Mark all as read</button>` : ""}
      </div>
      ${reports.length ? "" : p.reports.length ? `<p class="empty">All reports are archived.</p>` : `<p class="empty">Files you put in <b>projects/${esc(p.name)}/reports</b> show up here, newest first.</p>`}
      <ul class="list">${reports.map(r => `
        <li class="${r.read ? "read" : "unread"}">${reportLink(r)}
        <span class="date">${r.modified}</span>
        <button class="readbtn" data-read="${esc(r.name)}" aria-pressed="${r.read}"
          aria-label="${r.read ? "Read. Click to mark as unread" : "Unread. Click to mark as read"}: ${esc(r.name)}">${r.read ? "✓ Read" : "Mark read"}</button>
        <button class="archive" data-archive-report="${esc(r.name)}" title="Archive" aria-label="Archive report: ${esc(r.name)}">${ARCHIVE_ICON}</button></li>`).join("")}</ul>
    </section>
    ${archivedCount ? `<section class="archive-box">
      <details>
        <summary><h3>Archive (${archivedCount})</h3></summary>
        ${archivedTasks.length ? `<h4>Tasks</h4><ul class="list">${archivedTasks.map(t => `
          <li class="${t.done ? "done" : ""}"><span class="text">${esc(t.text)}</span>
          ${t.date ? `<span class="date">${t.date}</span>` : ""}
          <button class="restore" data-act="unarchive" data-i="${t.i}" aria-label="Restore task: ${esc(t.text)}">Restore</button></li>`).join("")}</ul>` : ""}
        ${archivedReports.length ? `<h4>Reports</h4><ul class="list">${archivedReports.map(r => `
          <li>${reportLink(r)}<span class="date">${r.modified}</span>
          <button class="restore" data-unarchive-report="${esc(r.name)}" aria-label="Restore report: ${esc(r.name)}">Restore</button></li>`).join("")}</ul>` : ""}
      </details>
    </section>` : ""}
    <div class="danger-zone"><button class="link-btn muted" data-remove-project>Remove project…</button></div>`;

  $("#add").onsubmit = async (e) => {
    e.preventDefault();
    const text = $("#newtask").value.trim();
    if (!text) return;
    lastChanged = text;
    await update("add", { text });
    $("#newtask").focus();
  };
  $("#main").dataset.tasks = JSON.stringify(p.tasks);
  const pr = projects.find(x => x.name === p.name);
  if (pr) { pr.open = open.length; pr.unread = unread; renderTabs(); }
  lastChanged = null;
}

async function update(action, body) {
  try { render(await api(`/api/project/${encodeURIComponent(current)}/${action}`, body)); }
  catch (e) { toast(e.message); openProject(current); }
}

document.addEventListener("click", (e) => {
  const tab = e.target.closest(".tab");
  if (tab) return openProject(tab.dataset.name);
  if (e.target.closest("[data-remove-project]")) return removeProject(current);
  if (e.target.closest("[data-rename-project]")) return openRenameDialog();
  const readBtn = e.target.closest("[data-read]");
  if (readBtn) return update("read", { name: readBtn.dataset.read, read: readBtn.getAttribute("aria-pressed") !== "true" });
  const arcBtn = e.target.closest("[data-archive-report]");
  if (arcBtn) return update("archive-report", { name: arcBtn.dataset.archiveReport });
  const unarcBtn = e.target.closest("[data-unarchive-report]");
  if (unarcBtn) return update("unarchive-report", { name: unarcBtn.dataset.unarchiveReport });
  if (e.target.closest("[data-allread]")) {
    const n = $("#main").querySelectorAll(".reports li.unread").length;
    if (confirm(`Mark all ${n} reports in ${current} as read?`)) update("readall", {});
    return;
  }
  const btn = e.target.closest("[data-act]");
  if (!btn) return;
  const tasks = JSON.parse($("#main").dataset.tasks);
  const i = +btn.dataset.i, text = tasks[i].text;
  if (btn.dataset.act === "delete" && !confirm(`Delete "${text}"?`)) return;
  lastChanged = text;
  update(btn.dataset.act, { index: i, text });
});

// Tell the tracker this page is still open, so it keeps running.
setInterval(() => fetch("/api/ping").catch(() => {}), 20000);

// Pick up changes made on another computer (via Dropbox) when you come back to this tab.
document.addEventListener("visibilitychange", () => { if (!document.hidden) loadProjects(); });

loadProjects().catch(() => {
  $("#main").innerHTML = `<h2 class="title">The tracker isn't running</h2>
    <p class="subtitle">It stops by itself a few minutes after you close this page. Double-click <b>Research Hub</b> in research_hub/tracker to start it again, then reload this page.</p>`;
});
</script>
</body>
</html>
"""


def main():
    url = f"http://127.0.0.1:{PORT}"
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print(f"The tracker already seems to be running. Opening {url}")
        webbrowser.open(url)
        return
    print(f"Research Hub v{VERSION} is running at {url}")
    print(f"Projects folder: {PROJECTS}")
    print("It stops by itself a few minutes after you close the hub page.")
    threading.Timer(0.6, lambda: webbrowser.open(url)).start()

    def stop_when_idle():
        while time.time() - last_seen < IDLE_LIMIT:
            time.sleep(15)
        server.shutdown()

    threading.Thread(target=stop_when_idle, daemon=True).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    sys.exit(main())
