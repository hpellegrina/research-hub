#!/bin/bash
# Start the tracker in the background, then exit so this Terminal window closes.
# The tracker stops by itself a few minutes after the hub page is closed.
cd "$(dirname "$0")"
mkdir -p "$HOME/Library/Logs"
nohup python3 tracker.py >> "$HOME/Library/Logs/Research Hub.log" 2>&1 &
disown
exit 0
